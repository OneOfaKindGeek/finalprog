var game=function() {
let pScore=0;
let cScore=0;

//starts the game
var StartGame=function() {
    // makes intro screen disapeer, and match screen appear 
    var PlayerButton=document.querySelector('.intro button');
    var Intro=document.querySelector('.intro');
    var match=document.querySelector('.match');  
    var options=document.querySelector('.options');
    PlayerButton.addEventListener('click', function() {
        Intro.classList.add('fadeOut'); 
        match.classList.add('fadeIn');
        options.classList.add('fadeIn'); 
    });
};
// code effects images in accordance with the button selected 
var playmatch = function(){
    var options2= document.querySelectorAll('.options button');
    var playerelement= document.querySelector('.player-element');
    var computerelement= document.querySelector('.computer-element');

    var computerOptions= ['earth', 'wind', 'fire'];
    //Code for computer to randomly select 
    options2.forEach(option=>{
        option.addEventListener('click', function(){
            var computerNumber= Math.floor(Math.random()*3);
            var computerChoice= computerOptions[computerNumber]   
            
            elementsCompared(this.textContent, computerChoice);

            playerelement.src=`./img/${this.textContent}.png`;
            computerelement.src=`./img/${computerChoice}.png`;
        });
    
    });
};
// code for updating  score
var updateScore= function(){
    var playerScore= document.querySelector('.player-score p'); 
    var computerScore= document.querySelector('.computer-score p'); 
    playerScore.textContent= pScore;
    computerScore.textContent= cScore;

}
// the statments to change the text, === means we are testing for strict equality 
// This means both the type and the value we are comparing have to be the same.
var elementsCompared= function(playerChoice, computerChoice){
    var winner=document.querySelector('.winner');
if(playerChoice===computerChoice){
winner.textContent='THE BATTLE HAS ENDED IN A DRAW!';
return;
};
// check for earth
if(playerChoice==='earth'){
if(computerChoice=== 'wind'){
 winner.textContent= 'THE AVATAR WINS!'
 pScore++;
 updateScore();
return; //ends the loop
} else{
     winner.textContent= 'THE PUNY MACHINE WINS, YOU LOSE!';
     cScore++;
     updateScore();
     return;
  }};
//check for fire
if(playerChoice==='fire'){
    if(computerChoice=== 'wind'){
     winner.textContent= 'THE PUNY MACHINE WINS, YOU LOSE!'
     cScore++;
     updateScore();
    return;
    } else{
         winner.textContent= 'THE AVATAR WINS!';
         pScore++;
         updateScore();
         return;
      }};
//check for wind
if(playerChoice==='wind'){
    if(computerChoice=== 'earth'){
     winner.textContent= 'THE PUNY MACHINE WINS, YOU LOSE!'
     cScore++;
     updateScore();
    return;
    } else{
         winner.textContent= 'THE AVATAR WINS!';
         pScore++;
         updateScore();
         return;
      }};    

};

// exicutes these functions
StartGame();
playmatch();
};
//start the game fuction
game();



